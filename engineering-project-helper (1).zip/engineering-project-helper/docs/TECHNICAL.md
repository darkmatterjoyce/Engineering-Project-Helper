# Engineering Project Helper: technical notes

The full write-up: how a run works, the decision log, the Bar Raiser, partial rebuilds, memory, the breadboard and firmware views, the API and the repo layout. The project overview is in the [README](../README.md).

**One sentence in → a buildable ESP32 project out.** Parts list (verified against live web sources,
with citations), a validated wiring map, firmware that **actually compiles**, and a code-flow diagram.
Every choice the agent makes is stored in a **versioned decision log with dependencies** in MongoDB,
so you can see *why* each part and pin was chosen and exactly what has to be rebuilt when something changes.
An independent **Bar Raiser** reviews every decision and sends serious problems back to be fixed, and you
can change any decision and rebuild **only what depends on it**. Approved projects become **precedents** in
MongoDB, so the agent remembers past designs and the mistakes it was caught making. The wiring is drawn as
a **breadboard picture** you can follow while building.

Built at the Imperial AI Society hackathon (Autonomous Agents track).

```
"an ESP32 that waters my plant when the soil is dry"
        │
        ▼
 requirements ─► parts ─► wiring ─► firmware ─► code-flow diagram
   (Claude)     (Claude +  (Claude +   (Claude +     (Claude)
                 Linkup)   ESP32 pin   arduino-cli
                           validator)  compile loop)
        └──────────── all read/write the decision log (MongoDB) ────────────┘
                                   │
                                   ▼
             Bar Raiser review (separate model) ──high-severity challenge──┐
                    ▲                                                     │
                    └──── partial rebuild of the affected stages ◄────────┘
```

## Merged workflow (Eric + Joyce)

The pipeline below is wrapped in the agreed product flow:

1. **Develop project** → the agent asks **at most 2 essential questions** (`/api/clarify`, `eph/clarify.py`).
   A stated budget becomes `req.budget`.
2. Before any design exists, the **Bar Raiser writes acceptance criteria** from the request + answers
   (`bar_raiser.brief`). They are stored on the run and never shown to the builder.
3. The builder runs requirements → parts → wiring → **procurement** → firmware → diagram. Procurement
   (`stages/procurement.py`, no LLM) turns the parts list (including **mechanical** parts like a chassis,
   tubing or an enclosure) into a cart with Linkup buy links, live-or-estimate prices and a **budget check**.
   If the builder can't meet an explicit request (e.g. "a camera"), it records a `deviation.*` decision.
4. **Two-stage review**: (A) the Bar Raiser reviews **results only** against its criteria; (B) it then reads
   the builder's rationale (the logbook) and keeps / downgrades / withdraws each challenge.
5. **Engineer reflects** (`eph/engineer.py`): it accepts or rejects every standing challenge with a reason and
   keeps the final say. Accepted → partial rebuild → the changed decisions are reviewed again.
   Rejected high/medium → **disagreements** for the user.
6. **Final acceptance check**: the Bar Raiser scores every criterion on the final delivery (agreement between
   agents is not evidence). The run ends `delivered` or `delivered_with_gaps`, with every gap listed:
   unmet criteria, deviations, firmware not compiled, estimated prices, over budget.
7. The user **judges disagreements** (Bar Raiser right / engineer right / neither + reason). The verdict is
   stored in the precedent, and both sides see it on similar future projects.
8. **Improve project** = continue the same run with free-text feedback: the Bar Raiser records what the user
   disliked and adds criteria, the feedback is mapped onto decisions, and only their downstream is rebuilt,
   then steps 4–7 run again.

**Offline by default:** `EPH_MOCK` now defaults to `1`, so nothing calls a paid API unless you set
`EPH_MOCK=0`. The mock covers the whole flow for the plant-waterer prompt (try answering the budget question
with "£30", judging the OLED disagreement, then "use a 16x2 I2C LCD instead of the OLED").

## Quick start

**Windows (Command Prompt):**
```
cd %USERPROFILE%\Downloads\engineering-project-helper\engineering-project-helper
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
set EPH_MOCK=1
uvicorn eph.api:app --reload
```
Then open http://localhost:8000. For real runs: `copy .env.example .env`, fill in keys, `set EPH_MOCK=`,
restart. The ESP32 compiler on Windows: `winget install ArduinoSA.CLI`, then the `arduino-cli` commands in
`scripts/setup_arduino.sh, scripts/init_atlas.py`.

**macOS / Linux:**
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 1) Offline demo: no keys, no DB, canned responses
EPH_MOCK=1 uvicorn eph.api:app --reload        # open http://localhost:8000

# 2) Real run
cp .env.example .env        # add ANTHROPIC_API_KEY, MONGODB_URI, LINKUP_API_KEY
./scripts/setup_arduino.sh  # arduino-cli + ESP32 core (needed for real compiles; ~5 min)
# Windows: python scripts\setup_arduino_windows.py  (installs arduino-cli via winget + ESP32 core, writes ARDUINO_CLI to .env)
uvicorn eph.api:app --reload

# CLI (writes ./out/<run_id>/: .ino, parts.json, wiring.json, *.mmd, decision_log.json)
python -m eph.cli "a desk air-quality monitor with CO2 readings on a small screen"

# Tests (offline)
pytest -q
```

Header chips in the UI show which providers are live (LLM, search, DB, compiler), so you can tell at a
glance whether you're in mock mode before demoing.

## Using the app

**Develop project:** type the idea, pick an **Engineer** model and a **Bar Raiser** model, press **Build with it**.
Every model the backend supports is listed; ones whose provider has no API key in `.env` are greyed out
("no key"). By default the Bar Raiser is a *different AI company* from the Engineer when you have keys for
two, which gives the most independent review. "Offline demo" needs no key.

**Improve project:** 1) choose a finished project, 2) describe the improvement, press **Improve it**. It reuses
that project's models and rebuilds only what the request touches.

**Tabs**

| Tab | What's in it |
|---|---|
| Overview | **Project guidance** first: what the project is and how it works, numbered build steps, a connection checklist generated from the validated pin map, test & calibrate, safety, troubleshooting (`stages/guide.py`, one LLM call, rewritten on any rebuild that changes parts/wiring/firmware). Then, at a glance: summary and the acceptance criteria it meets |
| BoM | bill of materials: every part with specs, verification, price and a **Buy** link |
| Wiring | breadboard picture, pin map, support components, pin validator |
| Firmware | code linked to the flow diagram (click a line or a diagram step) |
| For improvement | everything that needs you: Bar Raiser verdict, disagreements to judge, unmet criteria and gaps, the improve box, full review history |
| Other | decision log, agent activity, dependency graph, memory |

## Choosing the LLM (including free options)

| Provider | Cost | Set in `.env` | Default builder / Bar Raiser models |
|---|---|---|---|
| Anthropic Claude | paid | `ANTHROPIC_API_KEY` | `claude-sonnet-5-5` / `claude-opus-5-5` |
| Google Gemini | **free tier, no card** ([key](https://aistudio.google.com/apikey)) | `GEMINI_API_KEY` | `gemini-3.8-flash` / `gemini-3.6-flash` |
| Groq | **free tier, no card** ([key](https://console.groq.com/keys)) | `GROQ_API_KEY` | `openai/gpt-oss-120b` / `llama-3.3-70b-versatile` |
| Any OpenAI-compatible (Databricks, OpenRouter…) | varies | `OPENAI_COMPAT_BASE_URL`, `OPENAI_COMPAT_API_KEY`, `EPH_MODEL` | you choose |

Keys in `.env` decide which models are selectable in the Engineer / Bar Raiser pickers (`GET /api/models`).
Set `EPH_MOCK=0` so the pickers default to a real model instead of the offline demo. The first provider with a key is used, or force one with
`EPH_LLM_PROVIDER`. A full run makes about **23 LLM calls**, so free tiers give a handful of runs per day per
project. Builder and reviewer use different models (more independent review, and free-tier limits are per
model). Free-tier limits are per Google Cloud project, so each teammate's own key has its own quota.

The OpenAI-compatible client (`eph/llm.py`) is built for free-tier quirks: forced tool calling falls back from
`tool_choice={function}` → `"required"` → `"auto"` + instruction (remembering what worked), schemas are
reduced to the subset Gemini accepts, 429s wait out the provider's retry delay, calls are spaced by
`EPH_LLM_MIN_INTERVAL`, JSON in a plain-text reply is accepted, and a reply missing required fields gets
one corrective retry.

## Stack (and why)

| Piece | Choice | Why |
|---|---|---|
| Language / server | Python 3.11+, FastAPI, uvicorn | fastest to iterate; one process serves the API and the UI |
| LLM | Anthropic Claude (`claude-sonnet-5-5`, change with `EPH_MODEL`) | every call is a **forced tool call** with a JSON schema, so there is no free-text parsing |
| Database | **Databricks** Delta tables (`databricks-sql-connector`), or MongoDB Atlas via `pymongo`, or `mongomock` in-memory | the decision log is document-shaped and graph-linked; see "Database backends" |
| Web search | **Linkup** `/v1/search` (`sourcedAnswer`); Tavily as fallback | verifies each part's pinout and voltage with citable sources |
| Compiler | `arduino-cli` + Arduino-ESP32 core 3.x | proves the firmware builds; errors are fed back to the LLM |
| UI | one static `web/index.html`, vanilla JS + Mermaid | no build step; renders wiring, code flow and dependency graph |

## How a run works

1. **Requirements** (`eph/stages/requirements.py`): Claude turns the sentence into features, power,
   connectivity and explicit assumptions. Each becomes a root decision (`req.*`).
2. **Parts** (`stages/parts.py`): Claude picks real hobbyist modules with exact model numbers, rejected
   alternatives and a search query each. Linkup searches run **in parallel** (and are cached in Mongo for
   7 days). A second Claude call checks each part *against the evidence only* and records supply voltage,
   logic level and the real pin labels. Unverified parts get their confidence cut. Each `part.*` decision
   depends on the features it satisfies.
3. **Wiring** (`stages/wiring.py`): Claude proposes a full pin map. A **deterministic ESP32 validator**
   (`eph/esp32.py`) rejects flash pins 6-11, outputs on input-only pins, ADC2 while Wi-Fi is on, GPIO
   clashes (shared I2C/SPI buses are allowed) and 5 V logic into 3.3 V pins, and warns on strapping and UART0
   pins. Errors go back to Claude until the map is clean. One `pin.<part>.<pin>` decision per wire, plus a
   Mermaid wiring diagram generated from the validated map (not by the LLM).
4. **Firmware** (`stages/firmware.py`): Claude writes the sketch with the pin table as a hard constraint
   (core 3.x APIs, non-blocking loop, placeholder Wi-Fi credentials). A static check confirms every assigned
   GPIO appears in the code; `arduino-cli compile --fqbn esp32:esp32:esp32` builds it, and compiler errors
   are fed back for up to 3 fix attempts. `fw.sketch` depends on every pin, part and feature.
5. **Code flow** (`stages/diagram.py`): Claude draws a Mermaid flowchart of `setup()`/`loop()` from the final
   code (`diag.flow` depends on `fw.sketch`).

6. **Bar Raiser review** (`eph/bar_raiser.py`): see below. High-severity challenges are rebuilt
   automatically, then the changed decisions are reviewed again (up to `EPH_REVIEW_ROUNDS`).

Stages never pass data in memory: each one reads its inputs from the decision log. That is what makes
partial rebuilds possible: any stage can be re-run alone against the current log.

## Breadboard view

The Wiring tab shows a picture of a real breadboard (`eph/breadboard.py`, SVG), drawn by code from the
validated pin map rather than by the LLM, so it always matches the pin table and the firmware:

* The ESP32 DevKit V1 straddles the centre gap with its pin names printed on it; used pins are highlighted.
* Top rails = 5 V (VIN) + GND, bottom rails = 3.3 V + GND, each fed from the ESP32's own power pins.
* Modules that need 5 V plug in along the top, 3.3 V modules along the bottom. Each is drawn as a card with
  labelled header pins in its row, and jumper wires go into free holes of the same column strip.
* Wires are coloured by net (red 5 V, orange 3.3 V, black GND, blue SDA, yellow SCL, …). Hover a wire to see
  what it connects.
* Resistors, diodes and capacitors from `support_components` are drawn as components across holes using their
  `ends` (diode stripe / capacitor polarity respected). Parts with no ESP32 pin, such as pumps and motors,
  sit beside the board with wires in.
* **Download SVG** in the UI; the CLI also writes `breadboard.svg`.

## Interactive firmware view

The **Firmware** tab combines the code and the code-flow diagram (the separate Code flow tab is gone):

* **Click a line**, drag across lines, or shift-click a range. The panel on the right explains the
  selection: the flow-diagram step(s) it implements, plus the plain-English explanation of the function or
  section it sits in (pins it touches, units, timing, gotchas).
* The matching **diagram steps light up** and the diagram scrolls to them. **Click a diagram step** to jump
  to the lines that implement it.
* **Explain in depth** asks Claude about exactly your selection (with the whole sketch and pin table as
  context). Answers are cached in MongoDB (`explanations`), so the same question is free the second time.
* With nothing selected, the panel lists every section (includes, globals, each function) as shortcuts.

How it stays accurate (`eph/codemap.py`): code splits the sketch into sections by brace matching, so section
line numbers are exact. The diagram stage's single LLM call (the same call that draws the diagram) explains
each section by id and maps each diagram node to a line range on a *numbered* listing. Those ranges are
validated (clamped to the file, reversed ranges fixed, unknown node ids dropped), and any diagram step left
without code lines is reported as a warning.

## Database backends

The store picks one backend at startup:

| `.env` | Backend | Notes |
|---|---|---|
| `MONGODB_URI` set | MongoDB Atlas | Atlas Vector Search for precedents |
| `DATABRICKS_HOST`, `DATABRICKS_HTTP_PATH`, `DATABRICKS_TOKEN` set | **Databricks** | Delta tables, survives restarts, queryable in Databricks SQL |
| neither | in-memory | lost on restart |

**How the Databricks backend works** (`eph/databricks_store.py`). The app's queries (latest version of a
decision, dependency walks, stale checks) run on an in-memory document engine, so the logic is identical
on every backend. Every write is mirrored to a Delta table per collection,
`<catalog>.<schema>.eph_<collection>` with columns `id`, `doc` (the JSON document) and `updated_at`.
A background thread batches writes every ~2 s into one `MERGE` per collection, so the agent never waits on
the SQL warehouse, and failed writes (e.g. the warehouse waking up) stay queued and retry. On startup the
tables are read back, so past projects, decisions, reviews and precedents reappear. Precedent search uses
cosine similarity over the loaded embeddings.

Setup (Free Edition works): **SQL Warehouses → your warehouse → Connection details** gives the host and
HTTP path; **Settings → Developer → Access tokens** makes the token. Then `python scripts/check_setup.py`.
Example queries in a Databricks SQL editor:

```sql
SELECT get_json_object(doc, '$.prompt') AS prompt, get_json_object(doc, '$.status') AS status
FROM workspace.eph.eph_runs ORDER BY updated_at DESC;

SELECT get_json_object(doc, '$.key') AS decision, get_json_object(doc, '$.version') AS v,
       get_json_object(doc, '$.status') AS status, get_json_object(doc, '$.rationale') AS why
FROM workspace.eph.eph_decisions WHERE get_json_object(doc, '$.run_id') = '<run id>';
```

## Memory: precedents in MongoDB

`eph/precedents.py`. When the Bar Raiser approves a run, a compact **precedent** is upserted into the
`precedents` collection: the prompt, features, parts, pin map, support components, and every Bar Raiser
challenge with its resolution (fixed / open / removed), plus an embedding.

At the start of each new run the prompt is embedded and the closest precedents are found with **Atlas Vector
Search** (`$vectorSearch`, cosine, filtered by embedding model). If the index doesn't exist or you're on the
in-memory DB, it falls back to exact cosine in Python. The matches are:

* given to the builder stages ("similar projects used these parts; the Bar Raiser flagged *this* on one of
  them, so avoid it"), recorded on decisions as `precedent_ids`;
* given to the Bar Raiser ("these issues came up on similar projects; check this design handles them").

**Offline demo:** build "an ESP32 that waters my plant when the soil is dry" (the Bar Raiser catches the pump
brown-out and a rebuild adds a capacitor), then build "water my garden when the soil is dry". The second run
recalls the first (score about 0.47), designs the capacitor in from the start and passes review with **no
rebuild**. The **Memory** tab shows the library, which precedents this run used, and lets you forget one.

**Embeddings:** Voyage AI (VoyageAI by MongoDB, `VOYAGE_API_KEY`, default `voyage-4-lite`) for semantic
matching. Without a key, an offline hashed bag-of-words + character n-gram embedding is used: free and
deterministic, but it matches wording rather than meaning.

**Atlas setup:** `python scripts/init_atlas.py` creates the vector index (`precedent_vectors_<dims>`).
If your tier can't create search indexes from a driver, it prints the JSON definition to paste into the
Atlas UI (Atlas Search → Create Search Index → Vector Search → JSON editor, collection `precedents`).

## The Bar Raiser

An independent reviewer, named after Amazon's hiring role whose job is to stop a bad decision even when the
team likes it. What makes it independent:

* **Different model**: `EPH_REVIEW_MODEL` (Opus by default) while the builder runs on Sonnet.
* **Different prompt**: adversarial, told it didn't make these decisions and owes them nothing.
* **Limited view**: it sees only the recorded decisions, their evidence (Linkup sources, validator
  output, compile log) and the final code, never the builder's prompts.

It reviews in three groups per round (design, hardware, software), so it costs about 3 calls. Each decision
version gets one `review = {verdict, severity, notes, suggested_fix, model, round}`, also kept in the
`reviews` collection as an audit trail.

* `approve`: fine.
* `challenge` / `reject` at `high` severity (configurable with `EPH_AUTOFIX_SEVERITY`): turned into a change
  request for the stage that owns the decision, and a partial rebuild runs. The new version is stamped
  `author: bar_raiser` with a `trigger` linking it to the challenge, then reviewed again.
* `low` / `medium`: kept as notes for the human; nothing is rebuilt.

The run ends with `review_status`: `approved`, `approved_with_notes` or `unresolved` (high challenges left
after the last round). The UI's **Bar Raiser** tab lists every challenge and whether it was *fixed in a later
version*, is still *open*, or its decision was *removed*.

## Partial rebuilds

Click any decision in the **Decision log**, type a change ("use a 16x2 I2C LCD instead of the OLED") and press
**Rebuild from here**. Bar Raiser challenges use exactly the same path.

1. `plan_rebuild` finds the decision's stage plus the stages owning everything in `Store.downstream(key)`.
   For example, changing `fw.sketch` re-runs firmware and diagram only; changing `part.oled` re-runs parts,
   wiring, firmware and diagram, but not requirements.
2. Each re-run stage gets the change request plus its **current decisions** with "keep these unless the
   change requires otherwise", so the model edits instead of starting over. Firmware gets the current
   sketch to edit.
3. **No-op dedupe**: re-deciding the same choice from the same input versions keeps the existing version,
   so unchanged decisions don't cascade. In the LCD example, 19 decisions stay at v1.
4. Decisions a re-run stage no longer produces (the OLED and its 4 pins) are marked `retired`.
5. Only the new versions are re-reviewed by the Bar Raiser.

Each rebuild is logged on the run (`rebuilds: [{source, targets, stages, changed, retired}]`).

### Offline demo of both

With `EPH_MOCK=1` the plant-waterer run shows the whole loop: the Bar Raiser flags that the pump's start-up
surge on the shared USB 5 V rail can brown out the ESP32 (high), `wiring.support` is rebuilt with a 470 µF bulk
capacitor (v2), the firmware and diagram follow, and round 2 approves it. Then try *Rebuild from here* on
`part.oled` with "use a 16x2 I2C LCD instead". Offline mode only knows this one project and this one change.

## The decision log

Full spec: [`docs/SCHEMA.md`](docs/SCHEMA.md). The short version:

* Every decision has a stable **key** (`part.oled`, `pin.oled.sda`, `fw.sketch`), a **choice**, a
  **rationale**, **rejected alternatives**, **evidence** (Linkup URLs, compiler log, validator output) and a
  **confidence**.
* Decisions are **immutable and versioned**: changing one inserts v2 and marks v1 `superseded`.
* `depends_on` records the exact **version** of each upstream decision used. So:
  * `Store.downstream(key)` gives the exact set to rebuild if `key` changes;
  * `Store.stale(run)` finds decisions built on outdated inputs.
* The UI's **Decision log** tab lets you click any decision for rationale, alternatives, sources and
  "if this changes, rebuild: …". The **Dependency graph** tab draws the whole DAG.

## Repo layout

```
eph/
  config.py          env/.env settings
  schema.py          Pydantic models: Decision, Run, Artifact, Evidence, Review
  databricks_store.py  Databricks backend: write-behind mirror of every collection into Delta tables
  db.py              store (MongoDB / Databricks / in-memory): versioned decisions, dependency queries, artifacts, search cache
  llm.py             Claude client (forced tool calls) + factory
  search.py          Linkup / Tavily clients + Mongo-backed cache
  bar_raiser.py      independent reviewer
  precedents.py      memory: embeddings, Atlas Vector Search, precedent records
  breadboard.py      breadboard picture (SVG) from the pin map
  codemap.py         firmware sections, numbered listing, line ranges ↔ diagram nodes
  explain.py         "explain these lines" (cached)
  esp32.py           ESP32 pin rules, validator, wiring-diagram generator
  compiler.py        arduino-cli wrapper, static checks, error trimming
  stages/            requirements, parts, wiring, firmware, diagram
  pipeline.py        orchestrator: stages, review loop, partial rebuilds
  mock.py            canned LLM + search for offline demo/tests
  api.py, cli.py     HTTP API + web UI host, command line
web/index.html       single-page UI
docs/SCHEMA.md       decision log schema
scripts/setup_arduino.sh
tests/test_core_run.py
```

## API

| Method | Path | |
|---|---|---|
| POST | `/api/runs` `{prompt}` | start a run (background) → `{run_id}` |
| GET | `/api/runs` | recent runs |
| GET | `/api/runs/{id}` | run + events, active decisions, latest artifacts, stale keys |
| GET | `/api/runs/{id}/graph` | decision DAG (nodes/edges) |
| GET | `/api/runs/{id}/decisions/{key}/history` | all versions of a decision |
| GET | `/api/runs/{id}/decisions/{key}/downstream` | what a change to `key` invalidates |
| POST | `/api/runs/{id}/rebuild` `{key, instruction}` | partial rebuild from one decision, then re-review |
| GET | `/api/runs/{id}/reviews` | every Bar Raiser review, with `resolution` (fixed / open / retired) |
| GET | `/api/runs/{id}/firmware` | download the `.ino` |
| GET | `/api/runs/{id}/breadboard.svg` | download the breadboard picture |
| POST | `/api/runs/{id}/explain` `{start, end}` | explain firmware lines (cached in MongoDB) |
| GET | `/api/precedents` | the agent's memory |
| DELETE | `/api/precedents/{id}` | forget one precedent |
| GET | `/api/health` | providers + toolchain status |

## Sponsor tracks

* **Databricks**: the default durable store. Every decision version, review, output and memory is a row in a
  Delta table (`eph/databricks_store.py`), queryable in Databricks SQL; live counts and ready-made queries are in
  the app under Behind the build → Storage.
* **MongoDB** (alternative store): Atlas holds the decision log (versioned, dependency-indexed), reviews, artifacts, a TTL search
  cache, and the agent's **memory**: precedents retrieved with **Atlas Vector Search**, optionally embedded with
  Voyage AI (VoyageAI by MongoDB).
* **Linkup**: every non-passive part is verified with a live `sourcedAnswer` search, and the citations are
  stored as evidence on the decision and shown in the UI.
* **Tavily**: drop-in fallback search provider (`TAVILY_API_KEY`).

## Build status (from the plan)

1. ✅ Decision log schema
2. ✅ Basic end-to-end run
3. ✅ **Bar Raiser**
4. ✅ **Precedents**
5. ✅ **Partial rebuilds**

## Notes and limits

* Target board is an ESP32 DevKit V1 (WROOM-32). Change `EPH_FQBN` for other ESP32 boards; the validator
  rules are WROOM-32-specific.
* Without `arduino-cli` + the ESP32 core, compile is reported as `skipped` (static checks still run) and the
  firmware decision's confidence is lowered.
* Generated wiring is for low-voltage hobby circuits; check current draw and power supply before connecting
  motors or pumps.
