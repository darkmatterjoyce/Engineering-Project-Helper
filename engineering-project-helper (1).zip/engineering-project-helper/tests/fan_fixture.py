# Reproduces the user's fan-controller layout (USB cable + gate resistor listed as parts, MOSFET only via support).
parts = {
    "usb_cable": {"name": "Micro-USB cable", "role": "power", "pins": ["VBUS", "D-", "D+", "ID", "GND"]},
    "gate_resistor": {"name": "Gate resistor 220 ohm", "role": "passive", "pins": ["pin 1", "pin 2"]},
    "ds18b20": {"name": "DS18B20 waterproof probe (with 4.7k pull-up)", "role": "sensor", "pins": ["VDD", "GND", "DQ"]},
    "fan": {"name": "5V DC fan 40mm or 50mm", "role": "actuator", "pins": ["+5V (RED)", "GND (BLACK)"]},
    "mosfet": {"name": "Logic-level N-MOSFET", "role": "driver", "model": "IRLZ44N", "pins": ["G", "D", "S"]},
}
connections = [
    {"part_id": "usb_cable", "part_pin": "VBUS", "esp32_pin": "VIN", "signal_type": "power"},
    {"part_id": "usb_cable", "part_pin": "GND", "esp32_pin": "GND", "signal_type": "power"},
    {"part_id": "gate_resistor", "part_pin": "pin 1", "esp32_pin": "GPIO16", "signal_type": "digital"},
    {"part_id": "ds18b20", "part_pin": "VDD", "esp32_pin": "3V3", "signal_type": "power"},
    {"part_id": "ds18b20", "part_pin": "GND", "esp32_pin": "GND", "signal_type": "power"},
    {"part_id": "ds18b20", "part_pin": "DQ", "esp32_pin": "GPIO4", "signal_type": "onewire"},
]
support = [
    {"kind": "resistor", "name": "Gate resistor", "value": "220 ohm", "ends": ["gate_resistor.pin 2", "mosfet.G"]},
    {"kind": "resistor", "name": "Gate pull-down", "value": "10k", "ends": ["mosfet.G", "GND"]},
    {"kind": "resistor", "name": "DS18B20 pull-up", "value": "4.7k", "ends": ["ds18b20.DQ", "3V3"]},
    {"kind": "diode", "name": "Flyback diode", "value": "1N5819", "ends": ["fan.+5V (RED)", "fan.GND (BLACK)"]},
    {"kind": "capacitor", "name": "Bulk capacitor", "value": "100 uF 10V", "ends": ["VIN", "GND"]},
    {"kind": "wire", "name": "fan_plus", "ends": ["fan.+5V (RED)", "VIN"]},
    {"kind": "wire", "name": "W_fan_minus", "ends": ["fan.GND (BLACK)", "mosfet.D"]},
    {"kind": "wire", "name": "mosfet_source", "ends": ["mosfet.S", "GND"]},
]
